use SzkolaHD;

if object_id('Koniec_roku', 'U') is not null drop table Koniec_roku;
if object_id('Junk', 'U') is not null drop table Junk;
if object_id('Data', 'U') is not null drop table Data;
if object_id('Klasa', 'U') is not null drop table Klasa;
if object_id('Przedmiot', 'U') is not null drop table Przedmiot;
if object_id('Uczen', 'U') is not null drop table Uczen;

go