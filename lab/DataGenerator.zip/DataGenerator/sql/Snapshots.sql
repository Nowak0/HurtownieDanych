/*CREATE DATABASE Szko�a_snapshot ON (
    NAME = Szko�a,
    FILENAME = 'C:\Users\piotr\OneDrive\Pulpit\Studia\SEMESTR 5\HURTOWNIE DANYCH\Snapshots\Szko�a_snapshot.ss'
    ) AS SNAPSHOT OF Szko�a;
GO
*/
CREATE DATABASE Szko�a_snapshot2 ON (
    NAME = Szko�a,
    FILENAME = 'C:\Users\piotr\OneDrive\Pulpit\Studia\SEMESTR 5\HURTOWNIE DANYCH\Snapshots\Szko�a_snapshot2.ss'
    ) AS SNAPSHOT OF Szko�a;
GO
